The archive "BuildYourMolecule" contains:


1. a file named "Code" containing:


-a file named "levels" with .txt documents for all 10 levels
 (showing: initial board disposition, atoms combination of the solution, list of atoms of the molecule + their bonds)

-a file named "resources" with all the multimedia content used in the code
 (pictures, audio, text descriptions)

-the java codes for all 7 classes
 (BoardPanel, Element, LevelPanel, MessageDialog, MovesPanel, SolutionPanel, BuildYourMolecule)


2. a file named "SolvedLevels" containing .txt documents with solutions for all levels
   (showing where the molecule should be built to win)


3. a PDF document named "BuildYourMolecule_report"


4. the readme text document