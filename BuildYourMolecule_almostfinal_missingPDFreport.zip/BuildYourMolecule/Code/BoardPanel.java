import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.AbstractAction;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.Timer;

//check if the user has the right result
//lets the atoms move
//draws the walls
@SuppressWarnings("serial") //removes errors in fonts
public class BoardPanel extends JPanel {

	private int[][] board;
	private int[][] boardOriginal;
	private int[][] solution;
	private Element[] elements;
	private MovesPanel movesPanel;
	private BufferedImage walls; //BufferedImage allows the creation of an image
	private BufferedImage atoms;

	private int curRow;
	private int curCol;
	private int curX;
	private int curY;
	private int finRow;
	private int finCol;
	private int finX;
	private int finY;
	private int deltaX;
	private int deltaY;
	private int curAlpha;
	private int deltaAlpha;
	private double curAngle;
	private double deltaAngle;
	private double curScale;
	private double deltaScale;

	private List<int[]> movements; //mouvement animation with coordinates of the atom
	private int moveIndex; //changes position of atom

	private Timer animator;
	private boolean animating;
	private boolean fade;
	private boolean move;
	private boolean rotate;
	private boolean jump;
	private boolean won;
	private boolean playMoveAC;

	private enum Direction {UP, DOWN, LEFT, RIGHT} //enum: enumeration

	//sounds during the game (when atom moves or when user wins for example)
	private static AudioClip moveAC;
	private static AudioClip undoAC;
	private static AudioClip cheersAC;

	//runs this block of code until it catches an error
	static {
		try {
			moveAC = Applet.newAudioClip(BoardPanel.class.getResource("resources/move.au"));
			undoAC = Applet.newAudioClip(BoardPanel.class.getResource("resources/undo.wav"));
			cheersAC = Applet.newAudioClip(BoardPanel.class.getResource("resources/cheers.wav"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	//constructor of the board corresponding to the level+creates elements
	public BoardPanel(int[][] board, int[][] solution, Element[] elements) {
		this.boardOriginal = board;
		this.solution = solution;
		this.elements = elements;
		setInputListeners();
		setAnimator(); //to animate atoms
		reset(); 
	}
	//delays animation
	public void reset() {
		board = new int[boardOriginal.length][];
		for(int i = 0; i < board.length; i++) {
			board[i] = boardOriginal[i].clone(); //creates an instance similar to the original board to be sure there is no error
		}
		if (movesPanel == null){
			movesPanel = new MovesPanel();
		} else {
			movesPanel.reset();
		}
		curRow = 0; //current row of the board
		curCol = 0; //current column of the board
		curScale = 1.0;
		movements = new ArrayList<int[]>();
		moveIndex = -1; //didn't move yet
		won = false;
		playMoveAC = true; //starts playing
		drawWalls();
		drawAtoms();
		repaint();
	}
	//method to make the atoms move
	public void setAnimator() {
		animator = new Timer(8, new ActionListener() { //waits 8ms before moving the atom after click

			public void actionPerformed(ActionEvent e) {
				if ((finX == curX && finY == curY) || curAlpha == 20) { //check that current x and y are equal to real x and y, movement panel appears, animation can start
					int x = board[finRow][finCol];
					board[finRow][finCol] = board[curRow][curCol];
					board[curRow][curCol] = x;
					curRow = finRow;
					curCol = finCol;
					curX = curCol * Element.SIDE; //makes coordinates coorespond on board
					curY = curRow * Element.SIDE;
					curAngle = 0;
					curAlpha = 0;
					curScale = 1.0;
					animating = false;
					move = false;
					fade = false;
					rotate = false;
					jump = false;
					playMoveAC = true;
					movesPanel.repaint(); //mouvement arrows appear
					checkWon();
					animator.stop();
				} else {
					if ((finY == curY - 5 || finY == curY + 5 || finX == curX - 5 || finX == curX + 5 || curAlpha == 19) && playMoveAC){ //if outside panel bonds, can't play anymore
						moveAC.play();
						playMoveAC = false;
					}
					//when moves, will go to the biggest distance possible until meeting a wall
					//finx, finy: where you want to go
					//curx, cury: where you are
					double distance = Math.abs(finX - curX) + Math.abs(finY - curY);
					double middle = (Math.abs(finRow - curRow) + Math.abs(finCol - curCol)) * Element.SIDE / 2;
					if (distance > middle) {
						curScale += deltaScale;
					} else {
						curScale -= deltaScale;
					}
					curAngle += deltaAngle; 
					curAlpha += deltaAlpha;
					curX = (finX > curX)? curX + deltaX : (finX < curX)? curX - deltaX : curX;
					curY = (finY > curY)? curY + deltaY : (finY < curY)? curY - deltaY : curY;
				}
				repaint();
			}

		});
	}

	private void setInputListeners() {
		setBackground(new Color(255, 255, 255));
		setFocusable(true); //only shows button or combo box as clicked when clicked: gives cleaner appearance

		getInputMap().put(KeyStroke.getKeyStroke("UP"), "up"); //allows to use keayboard arrows instead of arrows painted on panel
		getActionMap().put("up", new AbstractAction() {

			public void actionPerformed(ActionEvent arg0) {
				moveAtom(Direction.UP); //moves atom up
			}

		});

		getInputMap().put(KeyStroke.getKeyStroke("LEFT"), "left");
		getActionMap().put("left", new AbstractAction() {

			public void actionPerformed(ActionEvent arg0) {
				moveAtom(Direction.LEFT);
			}

		});

		getInputMap().put(KeyStroke.getKeyStroke("RIGHT"), "right");
		getActionMap().put("right", new AbstractAction() {

			public void actionPerformed(ActionEvent arg0) {
				moveAtom(Direction.RIGHT);
			}

		});

		getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "down");
		getActionMap().put("down", new AbstractAction() {

			public void actionPerformed(ActionEvent arg0) {
				moveAtom(Direction.DOWN);
			}

		});

		getInputMap().put(KeyStroke.getKeyStroke("ESCAPE"), "exit"); //clicking "echap" key exits the game
		getActionMap().put("exit", new AbstractAction() {

			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}

		});

		addMouseListener(new MouseAdapter() {

			public void mousePressed(MouseEvent e) {
				if (animating || won) {
					return;
				}
				int c = e.getX() / Element.SIDE;
				int r = e.getY() / Element.SIDE;
				if (r >= 0 && r < board.length && c >= 0 && c < board[0].length) {
					if (board[r][c] > 0) {
						curRow = r;
						curCol = c;
						curX = curCol * Element.SIDE;
						curY = curRow * Element.SIDE;
						finRow = r;
						finCol = c;
						drawAtoms();
						repaint();
					} else if (board[curRow][curCol] > 0 && board[r][c] == 0) {
						if (r == curRow + 1 && c == curCol) {
							moveAtom(Direction.DOWN);
						}
						if (r == curRow - 1 && c == curCol) {
							moveAtom(Direction.UP);
						}
						if (c == curCol + 1 && r == curRow) {
							moveAtom(Direction.RIGHT);
						}
						if (c == curCol - 1 && r == curRow) {
							moveAtom(Direction.LEFT);
						}
					}
				}
			}

		});
	}
	//method to check if the molecule built is the right one
	private void checkWon() {
		for (int i = 0; i <= board.length - solution.length; i++) { //solution is a table containing the right disposition of the indexes of the elements
			for (int j = 0; j <= board[0].length - solution[0].length; j++) {
				if (areEqual(i, j)) {
					Graphics2D g2d = (Graphics2D)getGraphics(); 

					//winning message
					Rectangle2D rect = new Rectangle2D.Double(1, (getPreferredSize().height - 3 * Element.SIDE) / 2.0, getPreferredSize().width - 2, 3 * Element.SIDE);
			        g2d.setPaint(new GradientPaint(0, 0, new Color(245, 248, 251), getPreferredSize().width, 0, new Color(221, 232, 242)));
			        g2d.fill(rect);
					g2d.setColor(new Color(100, 150, 200));
					g2d.draw(rect);

					g2d.setFont(new Font("Comic sans ms", Font.PLAIN, Element.SIDE));
					FontMetrics fm = g2d.getFontMetrics(); //gives info about font
			        Rectangle2D r = fm.getStringBounds("YOU WIN (for now)!", g2d);
			        int x = (int) ((getPreferredSize().width - r.getWidth()) / 2);
			        int y = (int) (getPreferredSize().height - r.getHeight()) / 2 + fm.getAscent(); //sets text at a certain position (here: higher than middle of rectangle)
			        g2d.setColor(Color.BLACK);
			        g2d.drawString("YOU WIN (for now)!", x, y);

					cheersAC.play(); //audio with cheers
					//without this: bug with win message display
					try {
						Thread.sleep(2500);
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					won = true;
				}
			}
		}
	}
	//method to get a boolean determining if the user won
	private boolean areEqual(int r, int c) { //r and c are row and column
		for (int i = 0; i < solution.length; i++) {
			for (int j = 0; j < solution[0].length; j++) {
				if (solution[i][j] > 0) {
					if (board[i + r][j + c] < 1 || solution[i][j] != board[i + r][j + c]) //if all right elements are not aligned
						return false;
				}
			}
		}
		return true;
	}
	//method to move atoms
	private void moveAtom(Direction direction) {
		if (animating || won || board[curRow][curCol] < 1)
			return;

		if (direction == Direction.UP) {
			while (finRow > 0 && board[finRow - 1][finCol] == 0) {
				finRow--;
			}
		} else if (direction == Direction.DOWN) {
			while (finRow < board.length - 1 && board[finRow + 1][finCol] == 0) {
				finRow++;
			}
		} else if (direction == Direction.LEFT) {
			while (finCol > 0 && board[finRow][finCol - 1] == 0) {
				finCol--;
			}
		} else if (direction == Direction.RIGHT) {
			while (finCol < board[0].length - 1 && board[finRow][finCol + 1] == 0) {
				finCol++;
			}
		}
		if (curRow != finRow || curCol != finCol) {
			movesPanel.increment(); //increments: ++
			movements = movements.subList(0, moveIndex + 1); //keeps track of the moves made (for undo for example)
			movements.add(new int[]{curRow, curCol, finRow, finCol}); //moves
			moveIndex++;
			//animates mvmt
			setAnimationType();
			animateMovement();
		}
	}
	//atom rotates when moving
	private void setAnimationType() {
		animating = true;
		Random gen = new Random(); //gives random value
		do {
			move = gen.nextBoolean();
			fade = gen.nextBoolean();
		} while (!move && !fade);
		rotate = gen.nextBoolean();
		jump = fade ? false : gen.nextBoolean(); //when going to one side or another: atom fades on screen a little
	}

	private void animateMovement() {
		finX = finCol * Element.SIDE;
		finY = finRow * Element.SIDE;
		deltaX = move ? 5 : 0; //replaces if and else
		deltaY = move ? 5 : 0;
		deltaAngle = (!rotate)? 0 : (fade)? Math.PI / 10 : (10 * Math.PI / ((finY - curY) + (finX - curX)));
		deltaAlpha = (fade)? 1 : 0;
		deltaScale = jump? 0.02 : 0;
		animator.start();
	}
	///keep??
	public void traverseMovements(boolean undo) {
		if (animating || won)
			return;

		try {
			int[] positions;
			if (undo) {
				positions =  movements.get(moveIndex);
				moveIndex--;
				movesPanel.decrement();
				curRow = positions[2];
				curCol = positions[3];
				finRow = positions[0];
				finCol = positions[1];
			} else {
				positions =  movements.get(moveIndex + 1);
				moveIndex++;
				movesPanel.increment();
				curRow = positions[0];
				curCol = positions[1];
				finRow = positions[2];
				finCol = positions[3];
			}
			curX = curCol * Element.SIDE;
			curY = curRow * Element.SIDE;
			drawAtoms();
			animating = true;
			fade = true;
			playMoveAC = false;
			animateMovement();
			undoAC.play();
		} catch (Exception ex) {

		}
	}
	//method to put walls into place
	private void drawWalls() {
		walls = new BufferedImage(getPreferredSize().width, getPreferredSize().height, BufferedImage.TYPE_INT_ARGB); //adapts size with screen
		Graphics g = walls.getGraphics();
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[i].length; j++) {
				if (board[i][j] == -1) {
					g.drawImage(Element.WALL, j * Element.SIDE, i * Element.SIDE, null);
				}
			}
		}
		g.setColor(new Color(220, 220, 220));
		for (int i = 0; i <= board.length; i++) {
			g.drawLine(0, i * Element.SIDE, getPreferredSize().width, i * Element.SIDE);
		}
		for (int j = 0; j <= board[0].length; j++) {
			g.drawLine(j * Element.SIDE, 0, j * Element.SIDE, getPreferredSize().height);
		}
	}
	//method to display atoms
	public void drawAtoms() {
		atoms = new BufferedImage(Element.SIDE * (board[0].length + 1), Element.SIDE * (board.length + 1), BufferedImage.TYPE_INT_ARGB);
		Graphics g = atoms.getGraphics();
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[i].length; j++) {
				if (board[i][j] > 0 && !(i == curRow && j == curCol)) {
					g.drawImage(elements[board[i][j]].getImage(), j * Element.SIDE, i * Element.SIDE, null);
				}
			}
		}
	}

	public MovesPanel getMovesPanel() {
		return movesPanel;
	}

	public Dimension getPreferredSize() {
		return new Dimension(Element.SIDE * board[0].length, Element.SIDE * board.length);
	}
	//draws all elements (walls, elments) on board
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g; //library
		g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY); //uses library grpahics2D to manage keys on keyboard
		g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g2d.drawImage(walls, 0, 0, null);
		g2d.drawImage(atoms, 0, 0, null);

		if (board[curRow][curCol] < 1)
			return;
			
		//style
		Composite c = g2d.getComposite();
		g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) (1 - curAlpha * 0.05)));

		g2d.translate(curX + Element.SIDE / 2, curY + Element.SIDE / 2);
		g2d.rotate(curAngle);
		g2d.scale(curScale, curScale);
		g2d.drawImage(elements[board[curRow][curCol]].getImage(), -Element.SIDE / 2, -Element.SIDE / 2, null);
		g2d.scale(1 / curScale, 1 / curScale);
		g2d.rotate(-curAngle);
		g2d.translate(-curX - Element.SIDE / 2, -curY - Element.SIDE / 2);

		g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) (curAlpha * 0.05)));

		g2d.translate(finX + Element.SIDE / 2, finY + Element.SIDE / 2);
		g2d.rotate(curAngle);
		g2d.scale(curScale, curScale);
		g2d.drawImage(elements[board[curRow][curCol]].getImage(), -Element.SIDE / 2, -Element.SIDE / 2,  null);
		g2d.scale(1 / curScale, 1 / curScale);
		g2d.rotate(-curAngle);
		g2d.translate(-finX - Element.SIDE / 2, -finY - Element.SIDE / 2);

		g2d.setComposite(c);
		//draws arrows to move (only if mvmt is possible, i.e. not if there is a wall beside the atom)
		if (!animating && !won) {
			if (board[curRow - 1][curCol] == 0) {
				g2d.drawImage(Element.ARROW_DOWN, curCol * Element.SIDE, (curRow - 1) * Element.SIDE, null);
			}
			if (board[curRow + 1][curCol] == 0) {
				g2d.drawImage(Element.ARROW_UP, curCol * Element.SIDE, (curRow + 1) * Element.SIDE, null);
			}
			if (board[curRow][curCol - 1] == 0) {
				g2d.drawImage(Element.ARROW_LEFT, (curCol - 1) * Element.SIDE, curRow * Element.SIDE, null);
			}
			if (board[curRow][curCol + 1] == 0) {
				g2d.drawImage(Element.ARROW_RIGHT, (curCol + 1) * Element.SIDE, curRow * Element.SIDE, null);
			}
		}
	}

}
